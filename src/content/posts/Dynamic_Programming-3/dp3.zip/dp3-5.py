import sys
from collections import deque

input = lambda:sys.stdin.readline().strip()
N,V = map(int,input().split())
dp = [0] * (V+1)
for i in range(1,N+1):
    v,w,s = map(int,input().split())
    x = V % v
    d = deque(maxlen=s+1)
    while(x<=V):
        while d:
            d = deque([x + w for x in d],maxlen=s+1)
            if d[-1] <= dp[x]:
                d.pop()
            else:
                d.append(dp[x])
                break
        if not d:
            d.append(dp[x])
        dp[x] = d[0]
        x += v
print(dp[V])