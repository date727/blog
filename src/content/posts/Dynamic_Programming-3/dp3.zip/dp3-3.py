import queue
import sys
input = lambda: sys.stdin.readline().strip()
n,m = map(int, input().split())
queue = queue.PriorityQueue()
ans = []
numbers = list(map(int, input().split()))
for i in range(m):
    queue.put((0 - numbers[i],i))
x = queue.get()
ans.append(0 - x[0])
queue.put(x)
k = m
while k <= n-1:
    queue.put((0 - numbers[k],k))
    while True:
        x = queue.get()
        if 0 - x[0] in numbers[k-m+1:k+1]:
            ans.append(0 - x[0])
            queue.put(x)
            break
    k+=1
for i in ans:
    print(i,end=' ')