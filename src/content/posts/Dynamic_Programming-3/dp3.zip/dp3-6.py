import sys
from collections import deque

input = lambda: sys.stdin.readline().strip()
N, V = map(int, input().split())
dp = [0] * (V + 1)

for i in range(N):
    v, w, s = map(int, input().split())
    for r in range(v):
        d = deque(maxlen=s + 1)
        for k in range((V - r) // v + 1):
            val = dp[k * v + r] - k * w
            while d and d[-1][1] <= val:
                d.pop()
            d.append((k, val))
            if d[0][0] < k - s:
                d.popleft()
            dp[k * v + r] = d[0][1] + k * w

print(dp[V])