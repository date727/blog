from collections import deque
import sys
input = lambda: sys.stdin.readline().strip()
n,m = map(int, input().split())
numbers = list(map(int, input().split()))
ans=[]
d = deque()
for i in range(m):
    #判断队列是否为空
    while d:
        x = d.pop()
        if x > numbers[i]:
            d.append(x)
            d.append(numbers[i])
            break
    if not d:
        d.append(numbers[i])
ans.append(d[0])
k = m
while k < n:
    while d:
        x = d.pop()
        if x >= numbers[k]:
            d.append(x)
            d.append(numbers[k])
            break
    if not d:
        d.append(numbers[k])
    while True:
        x = d.popleft()
        if x in numbers[k-m+1:k+1]:
            d.appendleft(x)
            ans.append(d[0])
            break
    k+=1
for i in ans:
    print(i,end=' ')