import sys
input = lambda:sys.stdin.readline().strip()
N,V = map(int,input().split())
dp = [0] * (V+1)
for i in range(1,N+1):
    v,w,s = map(int,input().split())
    k=1
    v_list = []
    w_list = []
    while s>=k:
        s-=k
        v_list.append(k*v)
        w_list.append(k*w)
        k*=2
    if s > 0 :
        v_list.append(s*v)
        w_list.append(s*w)
    #对于同一种物品，使用01背包
    s = len(v_list)
    for k in range(0, s):
        for j in range(V, v_list[k]-1,-1):
            dp[j] = max(dp[j], dp[j - v_list[k]] + w_list[k])
print(dp[V])