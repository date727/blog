import sys
def Increasingsequence(n):
	dp = [1] * (n+1)
	for i in range (1,n+1):
		for j in range(1,i):
			if a[i-1] >= a[j-1] and dp[j] + 1 > dp[i]:
				dp[i] = dp[j] + 1
	dns = max(dp)
	i = n
	str = ""
	while i>0:
		if dp[i] == dns:
			str += a[i - 1]
			dns-=1
		i-=1
	return str[::-1]

input = lambda:sys.stdin.readline().strip()
a = input()
n = len(a)
str = Increasingsequence(n)
print(str)