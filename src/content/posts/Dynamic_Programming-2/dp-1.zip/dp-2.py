import sys
def dpproblem(i,j):
    if i==0 or j==0:
        return 0
    if dp[i][j] != -1:
        return dp[i][j]
    ans1 = 0
    ans2 = 0
    if w_list[i] <= j:
        ans1 = dpproblem(i - 1,j - w_list[i]) + v_list[i]
    ans2 = dpproblem(i - 1,j)
    return max(ans1,ans2)


input = lambda:sys.stdin.readline().strip()
N,V = map(int , input().split())
w_list = [0]*(N+1)
v_list = [0]*(N+1)
for i in range(1,N+1):
    w_list[i],v_list[i] = map(int,input().split())
dp = [[-1] * (V+1) for _ in range(N+1)]   #判断是否有数值可以直接返回
print(dpproblem(N,V))