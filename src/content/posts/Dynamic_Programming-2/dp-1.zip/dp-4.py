import sys
input = lambda:sys.stdin.readline().strip()
N,V = map(int , input().split())
dp = [[0] * (V+1) for _ in range(2)]   #滚动数组
for i in range(1,N+1):
    w,v = map(int,input().split())
    for j in range(1, V + 1):
        if w > j:
            dp[i%2][j] = dp[(i - 1)%2][j]   #只对数的标记%2，不需要对容量操作
        else:
            dp[i%2][j] = max(dp[(i - 1)%2][j - w] + v, dp[(i - 1)%2][j])
print(dp[N%2][V])