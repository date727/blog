import sys
input = lambda:sys.stdin.readline().strip()
N,V = map(int , input().split())
dp = [0] * (V+1)
for i in range(1,N+1):   #更新顺序不变
    w,v = map(int,input().split())
    for j in range(w,V+1):   #覆盖顺序改变
        dp[j] = max(dp[j - w] + v, dp[j])
print(dp[V])