from itertools import *
import sys
input = lambda:sys.stdin.readline().strip()
n,m = map(int,input().split())
#数列表
ls = list(map(int,input().split()))
#前缀和列表,注意这里有个添加0的处理
s = list(chain([0],list(accumulate(ls))))
for i in range(m):
    l,r = map(int,input().split())
    print(f"{s[r] - s[l-1]}")