ls = [1,2,3,4,5]
it = iter(ls)  #创建迭代器对象
for i in ls:
    print(i,end=' ')
print()
for i in ls:
    print(i,end=' ')
print()
for i in it:
    print(i,end=' ')
print()
for i in it:
    print(i,end=' ')
print()

from itertools import *
for i in count(2,4):
    if i == 18:
        break
    print(i,end=' ')
print()
f = 0
for i in cycle([1,2,3]):
    f += 1
    print(f"{i}:{f}")
    if f==3:
        break
for i in repeat("passion!",3):
    print(i)

#前缀和
for i in accumulate(range(1,5)):
    print(i,end= ' ')
print()
#前几项中最大的数字
for i in accumulate([2,1,3,8,4,6],max):
    print(i,end = ' ')
print()
for i in chain([1,4],"dsfe"):
    print(i,end=' ')
print()

for i in product([1,2],[3,4]):
    print(i, end=' ')
print()
for i in permutations([1,2,3],2):
    print(i,end=' ')
print()
for i in combinations([1,2,3],2):
    print(i,end=' ')
print()
for i in combinations_with_replacement([1,2,3],2):
    print(i,end=' ')