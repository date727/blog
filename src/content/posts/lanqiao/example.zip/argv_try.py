import sys
print(sys.argv)
print(sys.argv[0])
print(sys.argv[1])