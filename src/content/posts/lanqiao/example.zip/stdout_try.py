import sys
lines=["25%","50%","75%","100%"]
for i in lines:
    sys.stdout.write(i)
    sys.stdout.write('\n')
    sys.stdout.flush()