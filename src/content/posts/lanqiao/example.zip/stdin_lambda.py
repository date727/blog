import sys
input = lambda:sys.stdin.readline().strip()
num = int(input())
print("{}".format(num))