import sys
input = lambda: sys.stdin.readline().strip()
N,T,W = map(int, input().split())
dp = [[0] * (W+1) for _ in range(T+1)]
for i in range(N):
    t,c = map(int, input().split())
    for j in range(T,t-1,-1):
        for k in range(W,c-1,-1):
            dp[j][k] = max(dp[j][k], dp[j-t][k-c]+1)
print(dp[T][W])