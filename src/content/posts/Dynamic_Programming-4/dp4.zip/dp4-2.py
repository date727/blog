import sys
input = lambda: sys.stdin.readline().strip()
m,n = map(int, input().split())
t = [[0] * 1001 for _ in range(101)]
W=[0] * (n+1)
V=[0] * (n+1)
num = [0] * 101
sum = 0
for i in range(1,n+1):
    V[i], W[i], x= map(int, input().split())
    sum = max(sum,x)
    num[x]+=1
    t[x][num[x]] = i
dp = [0] * (m+1)
#遍历每一组
for i in range(1,sum+1):
    #遍历体积
    for k in range(m,-1, -1):
        #遍历物品
        for j in range(1,num[i]+1):
            if k >=V[t[i][j]] :
                dp[k] = max(dp[k],dp[k-V[t[i][j]]]+W[t[i][j]])
print(dp[m])