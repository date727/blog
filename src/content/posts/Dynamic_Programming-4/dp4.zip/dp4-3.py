import sys
input = lambda: sys.stdin.readline().strip()
m,n = map(int, input().split())
t = [[0] * 5 for _ in range(61)]
v_l = [[0] * 5 for _ in range(61)]
num = [0] * 61
for i in range(1,n+1):
    v,p,q= map(int, input().split())
    if q==0:
        t[i][1] = v * p
        v_l[i][1] = v
        if num[i] == 0:
            num[i] = 1
        else:
            if num[i] == 4:
                t[i][3] += v * p
                v_l[i][3] += v
                t[i][4] += v * p
                v_l[i][4] += v
            t[i][2] += v * p
            v_l[i][2] += v
    else:
        #主件先出来的
        if i >= q:
            if t[q][2] == 0:
                t[q][2] = v * p + t[q][1]
                v_l[q][2] = v + v_l[q][1]
                num[q] = 2
            else:
                t[q][3] = v * p + t[q][1]
                v_l[q][3] = v + v_l[q][1]
                t[q][4] = v * p + t[q][2]
                v_l[q][4] = v + v_l[q][2]
                num[q] = 4
        #附件先出来的
        else:
            if t[q][2] == 0:
                t[q][2] = v * p
                v_l[q][2] = v
                num[q] = 2
            else:
                t[q][3] = v * p
                v_l[q][3] = v
                t[q][4] = v * p + t[q][2]
                v_l[q][4] = v + v_l[q][2]
                num[q] = 4
dp = [0] * (m+1)
#遍历每一组
for i in range(1,n+1):
    #遍历体积
    for k in range(m,-1, -1):
        #遍历物品
        for j in range(1,num[i]+1):
            if k >= v_l[i][j] :
                dp[k] = max(dp[k],dp[k-v_l[i][j]]+t[i][j])
print(dp[m])