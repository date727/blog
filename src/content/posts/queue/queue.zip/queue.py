import queue

fifo_queue = queue.Queue()
lifo_queue = queue.LifoQueue()
priority_queue = queue.PriorityQueue()

#put()
for i in range(5):
    fifo_queue.put(i)
    lifo_queue.put(i)

priority_queue.put((1,'java'))
priority_queue.put((2,'golang'))
priority_queue.put((0,'python'))
priority_queue.put((0,'c++'))

print(fifo_queue.get())
print(lifo_queue.get())
print(priority_queue.get())

print(f"fifo_queue:qsize:{fifo_queue.qsize()},full?:{fifo_queue.full()},empty?:{fifo_queue.empty()}")
print(f"lifo_queue:qsize:{lifo_queue.qsize()},full?:{lifo_queue.full()},empty?:{lifo_queue.empty()}")
print(f"priority_queue:qsize:{priority_queue.qsize()},full?:{priority_queue.full()},empty?:{priority_queue.empty()}")